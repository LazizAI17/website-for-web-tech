document.addEventListener('DOMContentLoaded', function() {
    animatePage();
});

function animatePage() {
    
    const header = document.querySelector('header');
    header.style.opacity = 0;
    header.style.transform = 'translateY(-20px)';
    
    setTimeout(() => {
        header.style.transition = 'opacity 0.4s ease, transform 0.6s ease';
        header.style.opacity = 1;
        header.style.transform = 'translateY(0)';
    }, 500);
}
