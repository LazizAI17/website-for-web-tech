document.addEventListener('DOMContentLoaded', function() {
    animatePage();
});

function animatePage() {
    
    const header = document.querySelector('header');
    header.style.opacity = 0;
    header.style.transform = 'translateY(-20px)';
    
    setTimeout(() => {
        header.style.transition = 'opacity 0.4s ease, transform 0.6s ease';
        header.style.opacity = 1;
        header.style.transform = 'translateY(0)';
    }, 500);
}
      // Countdown to the next celestial event (replace the date with an actual event date)
      const eventDate = new Date('December 31, 2023 23:59:59').getTime();

      const countdownElement = document.getElementById('countdown');
      const planetElement = document.getElementById('planet');

      setInterval(function () {
          const now = new Date().getTime();
          const distance = eventDate - now;

          const days = Math.floor(distance / (1000 * 60 * 60 * 24));
          const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
          const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
          const seconds = Math.floor((distance % (1000 * 60)) / 1000);

          countdownElement.innerHTML = `${days}d ${hours}h ${minutes}m ${seconds}s`;
      }, 1000);

      // Planet rotation animation
      function explore() {
          planetElement.style.transform = 'rotate(360deg)';
      }

      //stars for background
      document.addEventListener('DOMContentLoaded', function() {
        function createStars() {
          const stars = document.getElementById('stars');
          for (let i = 0; i < 100; i++) {
            const star = document.createElement('div');
            star.className = 'star';
            const xy = Math.random() * 100;
            const duration = 5 + Math.random() * 5;
            star.style.left = Math.random() * 100 + 'vw';
            star.style.top = Math.random() * 100 + 'vh';
            star.style.animationDuration = duration + 's';
            star.style.animationDelay = -duration * Math.random() + 's';
            stars.appendChild(star);
          }
        }
    
        createStars();
      });