document.addEventListener('DOMContentLoaded', function() {
    function createStars() {
      const stars = document.getElementById('stars');
      for (let i = 0; i < 100; i++) {
        const star = document.createElement('div');
        star.className = 'star';
        const xy = Math.random() * 100;
        const duration = 5 + Math.random() * 5;
        star.style.left = Math.random() * 100 + 'vw';
        star.style.top = Math.random() * 100 + 'vh';
        star.style.animationDuration = duration + 's';
        star.style.animationDelay = -duration * Math.random() + 's';
        stars.appendChild(star);
      }
    }

    createStars();
  });
  document.addEventListener('DOMContentLoaded', function() {
    animatePage();
});

function animatePage() {
    
    const header = document.querySelector('header');
    header.style.opacity = 0;
    header.style.transform = 'translateY(-20px)';
    
    setTimeout(() => {
        header.style.transition = 'opacity 0.4s ease, transform 0.6s ease';
        header.style.opacity = 1;
        header.style.transform = 'translateY(0)';
    }, 500);
}